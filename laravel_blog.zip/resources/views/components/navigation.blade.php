
<header>
<nav>
    <ul>
        <li><a href="/posts">Blogu Ieraksti</a></li>
        <li><a href="/posts/create">Izveidot Bloga Ierakstus</a></li>
        <li><a href="/categories">Kategorijas Saraksts</a></li>
        <li><a href="/categories/create">Izveidot Kategorijas Saturu</a></li>
    </ul>
</nav>
</header>
           