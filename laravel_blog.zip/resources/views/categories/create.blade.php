<x-layout>

    <x-slot:title>
        Izveidot kategoriju
    </x-slot:title>

    <div class="form-container">
        <h1>Kategorijas izveidošana</h1>

        <form method="POST" action="/categories">
            @csrf

            <input name="category_id" placeholder="Kategorijas nosaukums" required>
            <button type="submit">Pievienot kategoriju</button>

            @error("category_id")
                <p class="error-message">{{ $message }}</p>
            @enderror

        </form>
    </div>

</x-layout>