<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e($post->content); ?>

     <?php $__env->endSlot(); ?>

    <div class="post-container">
        <div class="post-content">
            <h1 class="post-title"><?php echo e($post->content); ?></h1>
            <h1 class="post-category">Kategorija: <?php echo e($post->category->category_name); ?></h1>

            <div class="action-buttons">
                <a href="/posts/<?php echo e($post->id); ?>/edit" class="edit-button">Rediģēt ierakstu</a>

                <form method="POST" action="/posts/<?php echo e($post->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("delete"); ?>
                    <button type="submit" class="delete-button">Izdzēst ierakstu</button>
                </form>
            </div>

            <hr>

            <form method="POST" action="/comments" class="comment-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="posts_id" value="<?php echo e($post->id); ?>">
                <input name="comment" placeholder="Komentārs" required>
                <input name="author" placeholder="Autors" required>
                <button type="submit">Pievienot komentāru</button>
            </form>
        </div>

        <div class="comments-section">
            <h2>Komentāri</h2>
            <?php $__currentLoopData = $post->comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comment">
                    <div class="comment-header">
                        <strong class="comment-author"><?php echo e($comment->author); ?></strong>
                        <span class="comment-date"><?php echo e($comment->created_at); ?></span>
                    </div>
                    <p class="comment-text"><?php echo e($comment->comment); ?></p>
                    <div class="comment-actions">
                        <a class="com-edit-button" href="/comments/<?php echo e($comment->id); ?>/edit">Rediģēt</a>
                        <form method="POST" action="/comments/<?php echo e($comment->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("delete"); ?>
                            <input name="posta_id" type="hidden" value="<?php echo e($post->id); ?>">
                            <button class="com-delete-button">Dzēst Komentāru</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel_blog\resources\views/posts/show.blade.php ENDPATH**/ ?>